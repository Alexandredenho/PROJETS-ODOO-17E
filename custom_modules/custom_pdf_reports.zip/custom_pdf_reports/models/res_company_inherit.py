from odoo import fields, models, api


class ResCompanyInherit(models.Model):
    _inherit = 'res.company'


