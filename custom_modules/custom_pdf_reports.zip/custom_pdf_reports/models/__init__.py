from . import purchase_order_inherit
from . import stock_picking_inherit
from . import account_payment_inherit
from . import res_company_inherit
from . import sale_order_inherit

